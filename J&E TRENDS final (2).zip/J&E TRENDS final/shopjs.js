// Wait for the DOM to fully load
document.addEventListener("DOMContentLoaded", () => {
  // Select all "Add to Cart" buttons
  const cartButtons = document.querySelectorAll(".add-to-cart");

  // Get the paragraph element where the cart message will be shown
  const message = document.getElementById("cart-message").querySelector("p");

  // Get the message container section
  const messageBox = document.getElementById("cart-message");

  // Add click event listener to each "Add to Cart" button
  cartButtons.forEach(button => {
    button.addEventListener("click", () => {
      // Get the name of the product from the parent card
      const productName = button.parentElement.querySelector("h2").innerText;

      // Display a confirmation message
      message.innerText = `${productName} added to your neon cart! ✨`;
      messageBox.style.display = "block";

      // Hide the message after 3 seconds
      setTimeout(() => {
        messageBox.style.display = "none";
      }, 3000);
    });
  });
});
