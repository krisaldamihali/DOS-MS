// Get reference to the form and response message paragraph
const form = document.getElementById("form");
const response = document.querySelector(".form-response");

// Add submit event listener to the form
form.addEventListener("submit", function (e) {
  e.preventDefault(); // Prevent form from reloading the page

  // Get trimmed values from input fields
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();

  // Check if any field is empty
  if (!name || !email || !message) {
    response.textContent = "Please fill in all fields."; // Show error message
    response.style.color = "#ff0000"; // Red color for error
    return; // Stop further execution
  }

  // Simulate sending process
  response.textContent = "Sending..."; // Show sending message
  response.style.color = "#00ffff"; // Neon blue color

  // After 1.5 seconds, show success message and reset form
  setTimeout(() => {
    response.textContent = "Message sent! We'll reply super soon 💌"; // Success message
    form.reset(); // Clear all form fields
  }, 1500);
});
