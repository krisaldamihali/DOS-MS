// Select all list items inside the "our-values" section
const values = document.querySelectorAll(".our-values li");

// Add a glow effect when the mouse is over a list item
values.forEach((li) => {
  li.addEventListener("mouseenter", () => {
    li.style.transform = "scale(1.05)"; // Slightly enlarge the item
    li.style.color = "#fff"; // Change the text color to white
    li.style.textShadow = "0 0 10px #ff00ff"; // Add a glowing pink shadow
  });

  // Remove the glow effect when the mouse leaves the item
  li.addEventListener("mouseleave", () => {
    li.style.transform = "scale(1)"; // Return to normal size
    li.style.color = "#ccc"; // Change the text color back to grey
    li.style.textShadow = "none"; // Remove the glowing shadow
  });
});

// Select the <h2> heading in the hero section
const heroText = document.querySelector(".about-hero h2");
let glow = true; // This is a flag to switch between glow styles

// Change the glow color every second to create a shimmer effect
setInterval(() => {
  heroText.style.textShadow = glow
    ? "0 0 15px #00ffff, 0 0 30px #00ffff" // Blue glow
    : "0 0 10px #ff00ff"; // Pink glow
  glow = !glow; // Toggle the flag to switch glow styles
}, 1000); // Runs every 1000 milliseconds (1 second)
