// This waits until the whole HTML page has loaded before running the code
document.addEventListener("DOMContentLoaded", () => {
  // This message will show in the browser console when the page is loaded
  console.log("Home page loaded!");

  // This gets the form where users can enter their email for the newsletter
  const form = document.getElementById("newsletter-form");

  // This runs when the user clicks the Subscribe button
  form.addEventListener("submit", (e) => {
    // This stops the form from sending data to another page
    e.preventDefault();

    // This gets the email the user typed in
    const email = form.querySelector("input[type='email']").value;

    // This shows a popup message saying thank you and showing the email
    alert(`Thanks for subscribing, fashionista! ✨ ${email}`);

    // This clears the form after the user clicks Subscribe
    form.reset();
  });

  // This selects all the feature items (the boxes with images and titles)
  const featureItems = document.querySelectorAll(".feature-item");

  // This runs for each feature item on the page
  featureItems.forEach(item => {
    // This runs when the mouse goes over the item
    item.addEventListener("mouseover", () => {
      // This changes the title color, size, and style
      item.querySelector("h3").style.color = "#00ffff";
      item.querySelector("h3").style.fontSize = "1.4rem";
      item.querySelector("h3").style.fontStyle = "italic";
    });

    // This runs when the mouse leaves the item
    item.addEventListener("mouseout", () => {
      // This puts the title back to normal style
      item.querySelector("h3").style.color = "#fff";
      item.querySelector("h3").style.fontSize = "1.2rem";
      item.querySelector("h3").style.fontStyle = "normal";
    });
  });
});
