// Wait until the DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
  console.log("Lookbook loaded 🎥");

  // Select all elements with the class "caption"
  const captions = document.querySelectorAll(".caption");

  // Loop through each caption and add hover effects
  captions.forEach(caption => {
    // Add sparkle emoji when mouse is over the caption
    caption.addEventListener("mouseover", () => {
      caption.innerText += " ✨";
    });

    // Remove sparkle emoji when mouse leaves the caption
    caption.addEventListener("mouseout", () => {
      caption.innerText = caption.innerText.replace(" ✨", "");
    });
  });
});
