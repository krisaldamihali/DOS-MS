#!/bin/bash

time java -jar openDLX.jar $1 $2
