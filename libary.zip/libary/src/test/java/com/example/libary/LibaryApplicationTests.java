package com.example.libary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
